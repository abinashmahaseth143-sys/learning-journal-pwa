const CACHE_NAME = "journal-v7";

const FILES_TO_CACHE = [
  "/",
  "/journal",
  "/about",
  "/projects",
  "/static/icon-192.png",
  "/static/icon-512.png"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(FILES_TO_CACHE);
    })
  );
  self.skipWaiting();
});

self.addEventListener("fetch", event => {
  if (event.request.url.includes("/api/")) {
    // Let API calls try network first
    event.respondWith(
      fetch(event.request).catch(() => {
        return new Response(JSON.stringify({error: "Offline"}), {
          headers: {"Content-Type": "application/json"}
        });
      })
    );
  } else {
    event.respondWith(
      caches.match(event.request).then(response => {
        return response || fetch(event.request);
      })
    );
  }
});