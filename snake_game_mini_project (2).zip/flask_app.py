from flask import Flask, render_template, request, jsonify
import json
import os
from datetime import datetime

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "reflections.json")

# Load / save reflections
def load_reflections():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return []

def save_reflections(reflections):
    with open(DATA_FILE, "w") as f:
        json.dump(reflections, f, indent=4)

# THIS IS THE MAGIC FIX – put it BEFORE your other page routes
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def catch_all(path):
    # Serve index.html for root, otherwise serve the requested .html file
    filename = 'index.html' if not path or path == '' else path
    if not filename.endswith('.html'):
        filename += '.html'
    return render_template(filename)

# Snake Game Route - ADD THIS
@app.route('/snake')
def snake_game():
    return render_template('snake-game.html')

# Your API routes (unchanged – they work perfectly)
@app.route("/api/reflections", methods=["GET"])
def get_reflections():
    return jsonify(load_reflections())

@app.route("/api/reflections", methods=["POST"])
def add_reflection():
    data = request.get_json()
    new_reflection = {
        "id": str(datetime.now().timestamp()),
        "name": data.get("name", "Unnamed"),
        "date": datetime.now().strftime("%a %b %d %Y"),
        "reflection": data["reflection"]
    }
    reflections = load_reflections()
    reflections.append(new_reflection)
    save_reflections(reflections)
    return jsonify(new_reflection), 201

@app.route("/api/reflections/<ref_id>", methods=["DELETE"])
def delete_reflection(ref_id):
    reflections = load_reflections()
    new_reflections = [r for r in reflections if r["id"] != ref_id]
    save_reflections(new_reflections)
    return jsonify({"message": "Reflection deleted"})

# Test & health routes
@app.route("/test")
def test():
    return "Flask is working! Routes are configured correctly."

@app.route("/health")
def health():
    return "Server is running!"

if __name__ == "__main__":
    app.run(debug=True)