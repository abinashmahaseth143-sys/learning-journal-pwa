// Journal functionality using Flask backend
class JournalManager {
    constructor() {
        this.entries = [];
    }

    // Load entries from Flask backend
    async loadEntries() {
        try {
            const response = await fetch("/api/reflections");
            this.entries = await response.json();
            this.displayEntries();
            this.updateCounter();
            console.log(`Loaded ${this.entries.length} reflections from server`);
        } catch (error) {
            console.error('Error loading entries:', error);
            this.showError('Failed to load reflections');
        }
    }

    // Submit new entry to Flask backend
    async submitEntry(reflectionText) {
        try {
            const words = reflectionText.trim().split(/\s+/);
            
            if (words.length < 10) {
                alert('Must be at least 10 words!');
                return;
            }

            const response = await fetch("/api/reflections", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    reflection: reflectionText
                })
            });

            const newEntry = await response.json();
            
            // Show success message
            alert('✅ Reflection saved to server!');
            
            // Reload entries to include the new one
            await this.loadEntries();
            return newEntry;
            
        } catch (error) {
            console.error('Error submitting entry:', error);
            alert('Error saving reflection');
        }
    }

    // Delete entry from Flask backend
    async deleteEntry(entryId) {
        if (confirm('Are you sure you want to delete this reflection?')) {
            try {
                await fetch(`/api/reflections/${entryId}`, {
                    method: "DELETE"
                });
                await this.loadEntries(); // Refresh the list
            } catch (error) {
                console.error('Error deleting entry:', error);
                alert('Failed to delete reflection');
            }
        }
    }

    // Display entries in the DOM
    displayEntries() {
        const container = document.getElementById('json-entries');
        if (!container) return;

        if (this.entries.length === 0) {
            container.innerHTML = `
                <div class="no-entries" style="text-align: center; padding: 40px; color: #666;">
                    <p>No reflections yet. Add your first reflection above!</p>
                </div>
            `;
            return;
        }

        let html = '';
        this.entries.forEach(entry => {
            html += `
                <div class="journal-entry">
                    <div class="entry-header">
                        <h3>${entry.name}</h3>
                        <span class="entry-date">${entry.date}</span>
                    </div>
                    <p>${entry.reflection}</p>
                    <div class="entry-footer">
                        <small>${entry.words} words</small>
                        <button class="delete-btn" onclick="journalManager.deleteEntry('${entry.id}')">
                            Delete
                        </button>
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
    }

    updateCounter() {
        const counter = document.getElementById('entry-counter');
        if (counter) {
            counter.textContent = `${this.entries.length} reflection(s) loaded from server`;
        }
    }

    showError(message) {
        const container = document.getElementById('json-entries');
        if (container) {
            container.innerHTML = `<div class="error" style="color: red; text-align: center;">${message}</div>`;
        }
    }

    // Download JSON file
    downloadJSON() {
        const dataStr = JSON.stringify(this.entries, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'reflections.json';
        a.click();
        URL.revokeObjectURL(url);
    }
}

// Initialize global instance
const journalManager = new JournalManager();

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Load existing entries
    journalManager.loadEntries();
    
    // Set up form submission
    const journalForm = document.getElementById('journal-form');
    if (journalForm) {
        journalForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const textarea = document.getElementById('journal-text');
            const text = textarea.value.trim();
            
            if (text) {
                await journalManager.submitEntry(text);
                textarea.value = ''; // Clear form
                
                // Reset word count
                const wordCount = document.getElementById('word-count');
                if (wordCount) {
                    wordCount.textContent = 'Words: 0';
                }
            }
        });
    }
    
    // Set up download button
    const downloadBtn = document.getElementById('download-json');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', () => {
            journalManager.downloadJSON();
        });
    }
    
    // Set up refresh button
    const refreshBtn = document.querySelector('button[onclick*="refresh"]');
    if (refreshBtn) {
        refreshBtn.onclick = () => journalManager.loadEntries();
    }
});