function getDate() {
    const d = new Date();
    let text = d.toDateString();
    document.getElementById("todayDate").innerHTML = text;
}

async function checkReflection() {
    let name = document.getElementById("fname").value;
    let reflection = document.getElementById("reflection").value;

    let entry = { name, reflection };

    let response = await fetch("/api/reflections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(entry)
    });

    if (response.ok) {
        document.myForm.reset();
        submitted();
    }
    return false;
}

async function submitted() {
    let output = "";

    let response = await fetch("/api/reflections");
    if (response.ok) {
        let reflections = await response.json();

        for (let r of reflections) {
            output += "<b>" + r.name + ":</b><br>" +
                "<i>" + r.date + "</i><br>" +
                r.reflection + "<br><br>";
        }

        if (reflections.length === 0) {
            output = "<i>No reflections found.</i>";
        }
    } else {
        output = "<i>Error loading reflections.</i>";
    }
    document.getElementById("viewAll").innerHTML = output;
}

function init() {
    getDate();
    submitted();
}